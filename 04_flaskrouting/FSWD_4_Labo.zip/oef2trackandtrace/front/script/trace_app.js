'use strict';


document.addEventListener('DOMContentLoaded', function() {
  console.info('DOM geladen');
 
});
