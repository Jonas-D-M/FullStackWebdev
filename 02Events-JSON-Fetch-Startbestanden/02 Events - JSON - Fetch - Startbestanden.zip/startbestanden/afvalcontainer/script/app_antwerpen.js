'use strict';

/* STAP 2: Schrijf een loadData functie die - via FETCH - communiseert met de API */

/* STAP 3: Als fetch gelukt is, wordt deze functie uitgevoerd om de data via INNERHTML te tonen */

/* STAP 1: Voeg DOMContentLoaded Event Listener toe  */

