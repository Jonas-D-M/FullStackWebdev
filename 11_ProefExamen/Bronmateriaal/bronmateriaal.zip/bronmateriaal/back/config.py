[connector_python]
user = root_fswd
host = 127.0.0.1
port = 3306
password = root_fswd
database = mendeljev

[application_config]
driver = 'SQL Server'
