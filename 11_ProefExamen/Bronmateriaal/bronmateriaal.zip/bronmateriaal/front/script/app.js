"use strict";

const backend_IP = "http://localhost:5000";
const backend = backend_IP + "/api/v1";

//#region ***  DOM references ***
let html_mendeljev;
let html_info;
let html_filter;
//#endregion

//#region ***  Callback-Visualisation - show___ ***
//#endregion

//#region ***  Callback-No Visualisation - callback___  ***
//#endregion

//#region ***  Data Access - get___ ***
//#endregion

//#region ***  Event Listeners - listenTo___ ***
//#endregion

//#region ***  INIT / DOMContentLoaded  ***
const init = function () {};
//#endregion

document.addEventListener("DOMContentLoaded", init);
