"use strict";

//#region ***  DOM references ***
//#endregion

//#region ***  Callback-Visualisation - show___ ***
//#endregion

//#region ***  Callback-No Visualisation - callback___  ***
//#endregion

//#region ***  Data Access - get___ ***
//#endregion

//#region ***  Event Listeners - listenTo___ ***
//#endregion

//#region ***  INIT / DOMContentLoaded  ***
const init = function() {
  console.log("🚂", "https://www.youtube.com/watch?v=8oVTXSntnA0");
};

document.addEventListener("DOMContentLoaded", init);
//#endregion
