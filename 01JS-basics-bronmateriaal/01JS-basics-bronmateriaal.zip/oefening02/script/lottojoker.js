'use strict';

const zodiac = [
	'boogschutter',
	'kreeft',
	'leeuw',
	'maagd',
	'ram',
	'schorpioen',
	'steenbok',
	'stier',
	'tweelingen',
	'vissen',
	'waterman',
	'weegschaal'
];
